# -*- coding: utf-8 -*-

"""
description: MySQL Database Configurations
"""
